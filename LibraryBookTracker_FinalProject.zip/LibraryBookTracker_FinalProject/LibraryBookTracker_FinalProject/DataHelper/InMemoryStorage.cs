﻿using LibraryBookTracker_FinalProject.Model;
using System;
using System.Collections.Generic;
using static System.Net.WebRequestMethods;

namespace LibraryBookTracker_FinalProject.DataHelper
{
    public static class InMemoryStorage
    {
        // Example salt (replace with a secure one)
        public static string salt = ")GN#447#^nryrETNwrbR%#&NBRE%#%BBDT#%";

        // In-memory storage for the entities
        public static List<Librarian> Librarians = new List<Librarian>();
        public static List<Patron> Patrons = new List<Patron>();
        public static List<Book> Books = new List<Book>();
        public static List<BorrowingRecord> BorrowingRecords = new List<BorrowingRecord>();

        static InMemoryStorage()
        {
            // Adding sample Librarians
            Librarians.Add(new Librarian
            {
                LibrarianId = 1,
                FirstName = "John",
                LastName = "Doe",
                Email = "john.doe@library.com",
                Username = "admin",
                Password = "dde6a80ee27ed148c86020e2cfaf6d28" // Hashed password example
            });

            // Adding sample Patrons
            Patrons.Add(new Patron
            {
                PatronsId = 1,
                FirstName = "Alice",
                LastName = "Johnson",
                Email = "alice.johnson@example.com",
                PhoneNumber = "123-456-7890",
                JoinDate = DateTime.Now.AddYears(-1)
            });

            Patrons.Add(new Patron
            {
                PatronsId = 2,
                FirstName = "Bob",
                LastName = "Smith",
                Email = "bob.smith@example.com",
                PhoneNumber = "987-654-3210",
                JoinDate = DateTime.Now.AddMonths(-3)
            });

            // Adding more sample Patrons
            Patrons.Add(new Patron
            {
                PatronsId = 3,
                FirstName = "Charlie",
                LastName = "Brown",
                Email = "charlie.brown@example.com",
                PhoneNumber = "555-123-4567",
                JoinDate = DateTime.Now.AddMonths(-6)
            });

            Patrons.Add(new Patron
            {
                PatronsId = 4,
                FirstName = "Diana",
                LastName = "Prince",
                Email = "diana.prince@example.com",
                PhoneNumber = "555-987-6543",
                JoinDate = DateTime.Now.AddYears(-2)
            });

            Patrons.Add(new Patron
            {
                PatronsId = 5,
                FirstName = "Ethan",
                LastName = "Hunt",
                Email = "ethan.hunt@example.com",
                PhoneNumber = "555-444-3333",
                JoinDate = DateTime.Now.AddMonths(-8)
            });

            Patrons.Add(new Patron
            {
                PatronsId = 6,
                FirstName = "Fiona",
                LastName = "Gallagher",
                Email = "fiona.gallagher@example.com",
                PhoneNumber = "555-222-1111",
                JoinDate = DateTime.Now.AddYears(-3)
            });

            Patrons.Add(new Patron
            {
                PatronsId = 7,
                FirstName = "George",
                LastName = "Michaels",
                Email = "george.michaels@example.com",
                PhoneNumber = "555-666-7777",
                JoinDate = DateTime.Now.AddDays(-150)
            });

            Patrons.Add(new Patron
            {
                PatronsId = 8,
                FirstName = "Hannah",
                LastName = "Baker",
                Email = "hannah.baker@example.com",
                PhoneNumber = "555-333-4444",
                JoinDate = DateTime.Now.AddMonths(-15)
            });

            Patrons.Add(new Patron
            {
                PatronsId = 9,
                FirstName = "Ian",
                LastName = "Fleming",
                Email = "ian.fleming@example.com",
                PhoneNumber = "555-777-8888",
                JoinDate = DateTime.Now.AddMonths(-20)
            });

            Patrons.Add(new Patron
            {
                PatronsId = 10,
                FirstName = "Jane",
                LastName = "Austen",
                Email = "jane.austen@example.com",
                PhoneNumber = "555-999-0000",
                JoinDate = DateTime.Now.AddYears(-1).AddMonths(-2)
            });

            // Adding sample Books
            Books.Add(new Book
            {
                BookId = 1,
                Title = "C# Programming",
                Author = "John Doe",
                ISBN = "1234567890123",
                PublishedDate = new DateTime(2020, 5, 15),
                Category = "Technology",
                TotalCopies = 5,
                AvailableCopies = 5,
                CoverImageUrl = "https://softuni.org/wp-content/uploads/2021/10/CSharp-Programming-Basics-Book-Cover-1-e1634038541437.png" // Example cover image URL
            });

            Books.Add(new Book
            {
                BookId = 2,
                Title = "Introduction to Algorithms",
                Author = "Thomas H. Cormen",
                ISBN = "9780262033848",
                PublishedDate = new DateTime(2009, 7, 31),
                Category = "Computer Science",
                TotalCopies = 3,
                AvailableCopies = 3,
                CoverImageUrl = "https://th.bing.com/th/id/OIP.yQajhsEchcAz_Bw7YwZITQAAAA?w=420&h=475&rs=1&pid=ImgDetMain" // Example cover image URL
            });

            Books.Add(new Book
            {
                BookId = 3,
                Title = "Clean Code",
                Author = "Robert C. Martin",
                ISBN = "9780132350884",
                PublishedDate = new DateTime(2008, 8, 1),
                Category = "Software Development",
                TotalCopies = 4,
                AvailableCopies = 4,
                CoverImageUrl = "https://img1.od-cdn.com/ImageType-100/6852-1/%7B06C4AD1E-9D1C-42B5-986D-BD6806FEEE5A%7DImg100.jpg" // Example cover image URL
            });

            Books.Add(new Book
            {
                BookId = 4,
                Title = "The Pragmatic Programmer",
                Author = "Andrew Hunt and David Thomas",
                ISBN = "9780201616224",
                PublishedDate = new DateTime(1999, 10, 20),
                Category = "Software Development",
                TotalCopies = 6,
                AvailableCopies = 6,
                CoverImageUrl = "https://m.media-amazon.com/images/I/41uPjEenkFL.jpg" // Example cover image URL
            });

            Books.Add(new Book
            {
                BookId = 5,
                Title = "Design Patterns: Elements of Reusable Object-Oriented Software",
                Author = "Erich Gamma, Richard Helm, Ralph Johnson, and John Vlissides",
                ISBN = "9780201633610",
                PublishedDate = new DateTime(1994, 10, 31),
                Category = "Software Development",
                TotalCopies = 5,
                AvailableCopies = 5,
                CoverImageUrl = "https://th.bing.com/th/id/OIP.EAouqSCn94VfFPXZ-1i4ogHaJ-?rs=1&pid=ImgDetMain" // Example cover image URL
            });

            Books.Add(new Book
            {
                BookId = 6,
                Title = "To Kill a Mockingbird",
                Author = "Harper Lee",
                ISBN = "9780061120084",
                PublishedDate = new DateTime(1960, 7, 11),
                Category = "Fiction",
                TotalCopies = 8,
                AvailableCopies = 8,
                CoverImageUrl = "https://cdn2.penguin.com.au/covers/original/9781784752637.jpg" // Example cover image URL
            });

            Books.Add(new Book
            {
                BookId = 7,
                Title = "1984",
                Author = "George Orwell",
                ISBN = "9780451524935",
                PublishedDate = new DateTime(1949, 6, 8),
                Category = "Dystopian",
                TotalCopies = 10,
                AvailableCopies = 10,
                CoverImageUrl = "https://th.bing.com/th/id/OIP.S4AzZN1Wvyk269nNiqGaTQHaMH?rs=1&pid=ImgDetMain" // Example cover image URL
            });

            Books.Add(new Book
            {
                BookId = 8,
                Title = "The Catcher in the Rye",
                Author = "J.D. Salinger",
                ISBN = "9780316769488",
                PublishedDate = new DateTime(1951, 7, 16),
                Category = "Fiction",
                TotalCopies = 5,
                AvailableCopies = 5,
                CoverImageUrl = "https://th.bing.com/th/id/OIP.SJrJBCkFxthW5BMIfUTZsgHaKV?rs=1&pid=ImgDetMain"
            });

            Books.Add(new Book
            {
                BookId = 9,
                Title = "Brave New World",
                Author = "Aldous Huxley",
                ISBN = "9780060850524",
                PublishedDate = new DateTime(1932, 8, 1),
                Category = "Dystopian",
                TotalCopies = 7,
                AvailableCopies = 7,
                CoverImageUrl = "https://img1.od-cdn.com/ImageType-400/0293-1/582/93F/4B/%7B58293F4B-F4B2-4937-A7EF-9E3B3A558C47%7DImg400.jpg"
            });

            Books.Add(new Book
            {
                BookId = 10,
                Title = "The Great Gatsby",
                Author = "F. Scott Fitzgerald",
                ISBN = "9780743273565",
                PublishedDate = new DateTime(1925, 4, 10),
                Category = "Fiction",
                TotalCopies = 6,
                AvailableCopies = 6,
                CoverImageUrl = "https://d28hgpri8am2if.cloudfront.net/book_images/onix/cvr9780743273565/the-great-gatsby-9780743273565_hr.jpg"
            });

            Books.Add(new Book
            {
                BookId = 11,
                Title = "Moby Dick",
                Author = "Herman Melville",
                ISBN = "9781503280786",
                PublishedDate = new DateTime(1851, 11, 14),
                Category = "Fiction",
                TotalCopies = 4,
                AvailableCopies = 4,
                CoverImageUrl = "https://images-na.ssl-images-amazon.com/images/S/compressed.photo.goodreads.com/books/1669512309i/63849929.jpg"
            });

            Books.Add(new Book
            {
                BookId = 12,
                Title = "War and Peace",
                Author = "Leo Tolstoy",
                ISBN = "9780143039990",
                PublishedDate = new DateTime(1869, 1, 1),
                Category = "Historical Fiction",
                TotalCopies = 3,
                AvailableCopies = 3,
                CoverImageUrl = "https://th.bing.com/th/id/OIP.IKbBafS4bOtZfBvnryGzzAHaLe?rs=1&pid=ImgDetMain"
            });

            Books.Add(new Book
            {
                BookId = 13,
                Title = "The Hobbit",
                Author = "J.R.R. Tolkien",
                ISBN = "9780345339683",
                PublishedDate = new DateTime(1937, 9, 21),
                Category = "Fantasy",
                TotalCopies = 10,
                AvailableCopies = 10,
                CoverImageUrl = "https://images.thenile.io/r1000/9780007270613.jpg"
            });

            Books.Add(new Book
            {
                BookId = 14,
                Title = "Harry Potter and the Sorcerer's Stone",
                Author = "J.K. Rowling",
                ISBN = "9780590353427",
                PublishedDate = new DateTime(1997, 9, 1),
                Category = "Fantasy",
                TotalCopies = 15,
                AvailableCopies = 15,
                CoverImageUrl = "https://cdn.kobo.com/book-images/63222867-476c-48c2-862f-a2604e09ce67/1200/1200/False/harry-potter-and-the-sorcerer-s-stone-the-first-book-in-the-phenomenal-internationally-bestselling-harry-potter-series-by-j-k-rowling.jpg"
            });

            Books.Add(new Book
            {
                BookId = 15,
                Title = "The Chronicles of Narnia",
                Author = "C.S. Lewis",
                ISBN = "9780066238500",
                PublishedDate = new DateTime(1950, 10, 16),
                Category = "Fantasy",
                TotalCopies = 8,
                AvailableCopies = 8,
                CoverImageUrl = "https://th.bing.com/th/id/OIP.gphrJ9Qhw7ONtONhfGuUHwHaLO?rs=1&pid=ImgDetMain"
            });

            Books.Add(new Book
            {
                BookId = 16,
                Title = "The Da Vinci Code",
                Author = "Dan Brown",
                ISBN = "9780307474278",
                PublishedDate = new DateTime(2003, 3, 18),
                Category = "Mystery",
                TotalCopies = 12,
                AvailableCopies = 12,
                CoverImageUrl = "https://th.bing.com/th/id/OIP.ApF07FI29I85KfMWlF_EZgAAAA?rs=1&pid=ImgDetMain"
            });

            Books.Add(new Book
            {
                BookId = 17,
                Title = "The Hunger Games",
                Author = "Suzanne Collins",
                ISBN = "9780439023481",
                PublishedDate = new DateTime(2008, 9, 14),
                Category = "Dystopian",
                TotalCopies = 20,
                AvailableCopies = 20,
                CoverImageUrl = "https://th.bing.com/th/id/R.4b4a90f337521e7152cebfb5e07d0a9c?rik=O2TnG9HTvOKr5w&riu=http%3a%2f%2f3.bp.blogspot.com%2f-HxVxhy2RH-0%2fVANY1W2HZRI%2fAAAAAAAAEig%2fvi6vPNg85ns%2fs1600%2fTheHungerGames.jpg&ehk=KQ4dOR22%2fOW%2bCyaVmxpK%2bANkKQXrjAOfaqvvVRBpsec%3d&risl=&pid=ImgRaw&r=0"
            });

            Books.Add(new Book
            {
                BookId = 18,
                Title = "Pride and Prejudice",
                Author = "Jane Austen",
                ISBN = "9780141439518",
                PublishedDate = new DateTime(1813, 1, 28),
                Category = "Romance",
                TotalCopies = 9,
                AvailableCopies = 9,
                CoverImageUrl = "https://d28hgpri8am2if.cloudfront.net/book_images/onix/cvr9781471134746/pride-and-prejudice-9781471134746_hr.jpg"
            });

            Books.Add(new Book
            {
                BookId = 19,
                Title = "The Catcher in the Rye",
                Author = "J.D. Salinger",
                ISBN = "9780316769488",
                PublishedDate = new DateTime(1951, 7, 16),
                Category = "Fiction",
                TotalCopies = 6,
                AvailableCopies = 6,
                CoverImageUrl = "https://www.bookishelf.com/wp-content/uploads/2020/01/Book-Review-The-Catcher-in-the-Rye-by-J-D-Salinger.jpg"
            });

            Books.Add(new Book
            {
                BookId = 20,
                Title = "The Girl with the Dragon Tattoo",
                Author = "Stieg Larsson",
                ISBN = "9780307454546",
                PublishedDate = new DateTime(2005, 8, 1),
                Category = "Mystery",
                TotalCopies = 14,
                AvailableCopies = 14,
                CoverImageUrl = "https://th.bing.com/th/id/OIP.JzTap-WuOXh2VPFBlkd98wAAAA?rs=1&pid=ImgDetMain"
            });
         
            Books.Add(new Book
            {
                BookId = 21,
                Title = "The Silent Patient",
                Author = "Alex Michaelides",
                ISBN = "9781250301697",
                PublishedDate = new DateTime(2019, 2, 5),
                Category = "Thriller",
                TotalCopies = 9,
                AvailableCopies = 9,
                CoverImageUrl = "https://th.bing.com/th/id/OIP.buEf0iZV0br5VKAU_cH2jgAAAA?rs=1&pid=ImgDetMain"
            });

            Books.Add(new Book
            {
                BookId = 22,
                Title = "The Secret History",
                Author = "Donna Tartt",
                ISBN = "9780679410321",
                PublishedDate = new DateTime(1992, 9, 1),
                Category = "Mystery",
                TotalCopies = 7,
                AvailableCopies = 7,
                CoverImageUrl = "https://images-na.ssl-images-amazon.com/images/S/compressed.photo.goodreads.com/books/1451554846i/29044.jpg"
            });

            Books.Add(new Book
            {
                BookId = 23,
                Title = "The Shining",
                Author = "Stephen King",
                ISBN = "9780307743657",
                PublishedDate = new DateTime(1977, 1, 28),
                Category = "Horror",
                TotalCopies = 10,
                AvailableCopies = 10,
                CoverImageUrl = "https://pictures.abebooks.com/isbn/9780307743657-us.jpg"
            });

            Books.Add(new Book
            {
                BookId = 24,
                Title = "It",
                Author = "Stephen King",
                ISBN = "9780450411434",
                PublishedDate = new DateTime(1986, 9, 15),
                Category = "Horror",
                TotalCopies = 12,
                AvailableCopies = 12,
                CoverImageUrl = "https://th.bing.com/th/id/OIP.3ubxFic7-I5F-QfZkgxKCwHaKe?rs=1&pid=ImgDetMain"
            });

            Books.Add(new Book
            {
                BookId = 25,
                Title = "The Handmaid's Tale",
                Author = "Margaret Atwood",
                ISBN = "9780385490818",
                PublishedDate = new DateTime(1985, 8, 1),
                Category = "Dystopian",
                TotalCopies = 6,
                AvailableCopies = 6,
                CoverImageUrl = "https://images.thenile.io/r1000/9781784873189.jpg"
            });

            Books.Add(new Book
            {
                BookId = 26,
                Title = "The Outsiders",
                Author = "S.E. Hinton",
                ISBN = "9780142407332",
                PublishedDate = new DateTime(1967, 4, 24),
                Category = "Young Adult",
                TotalCopies = 11,
                AvailableCopies = 11,
                CoverImageUrl = "https://th.bing.com/th/id/OIP.3FG-9lrxuoybtNP8PzY4pwAAAA?rs=1&pid=ImgDetMain"
            });

            Books.Add(new Book
            {
                BookId = 27,
                Title = "The Road",
                Author = "Cormac McCarthy",
                ISBN = "9780307387899",
                PublishedDate = new DateTime(2006, 9, 26),
                Category = "Dystopian",
                TotalCopies = 8,
                AvailableCopies = 8,
                CoverImageUrl = "https://images.thenile.io/r1000/9780330468466.jpg"
            });

            Books.Add(new Book
            {
                BookId = 28,
                Title = "Gone Girl",
                Author = "Gillian Flynn",
                ISBN = "9780307588371",
                PublishedDate = new DateTime(2012, 6, 5),
                Category = "Thriller",
                TotalCopies = 16,
                AvailableCopies = 16,
                CoverImageUrl = "https://th.bing.com/th/id/R.9237daf3639ed763c722fb15c4cc1534?rik=rT4hluXHeTy6xw&riu=http%3a%2f%2f3.bp.blogspot.com%2f-f6QoW1dbw08%2fVCA2kZO9U6I%2fAAAAAAAAF-Y%2fKt1je-ai49E%2fs1600%2fGONE_GIRL.jpg&ehk=NqddZmDcAEirqnhZeW9TsxzL04Qsr1ZHVYFE52T2eps%3d&risl=&pid=ImgRaw&r=0"
            });

            Books.Add(new Book
            {
                BookId = 29,
                Title = "The Hunger Games: Catching Fire",
                Author = "Suzanne Collins",
                ISBN = "9780439029520",
                PublishedDate = new DateTime(2009, 9, 1),
                Category = "Dystopian",
                TotalCopies = 15,
                AvailableCopies = 15,
                CoverImageUrl = "https://th.bing.com/th/id/R.2d65f9e1471503c19415316dcebe8a77?rik=qV7IwIx%2bGTPrsw&riu=http%3a%2f%2fstateofmind13.files.wordpress.com%2f2012%2f03%2fcatching-fire-book-cover.jpg&ehk=ydlUP1zVf5Rx%2fzr7RLGdgaOH3V6W8G7s5Ifh6cZyKBA%3d&risl=&pid=ImgRaw&r=0"
            });

            Books.Add(new Book
            {
                BookId = 30,
                Title = "The Hunger Games: Mockingjay",
                Author = "Suzanne Collins",
                ISBN = "9780439029544",
                PublishedDate = new DateTime(2010, 8, 24),
                Category = "Dystopian",
                TotalCopies = 12,
                AvailableCopies = 12,
                CoverImageUrl = "https://th.bing.com/th/id/OIP.jzZhS28lKWbwUQrVVrlMLQAAAA?rs=1&pid=ImgDetMain"
            });

            Books.Add(new Book
            {
                BookId = 31,
                Title = "The Night Circus",
                Author = "Erin Morgenstern",
                ISBN = "9780385534635",
                PublishedDate = new DateTime(2011, 9, 13),
                Category = "Fantasy",
                TotalCopies = 9,
                AvailableCopies = 9,
                CoverImageUrl = "https://cdn2.penguin.com.au/covers/original/9781446468265.jpg"
            });

            Books.Add(new Book
            {
                BookId = 32,
                Title = "Circe",
                Author = "Madeline Miller",
                ISBN = "9780316556347",
                PublishedDate = new DateTime(2018, 4, 10),
                Category = "Fantasy",
                TotalCopies = 10,
                AvailableCopies = 10,
                CoverImageUrl = "https://th.bing.com/th/id/OIP.wIQvCuezgwFptrLSoR5-SAHaLZ?rs=1&pid=ImgDetMain"
            });

            Books.Add(new Book
            {
                BookId = 33,
                Title = "The Nightingale",
                Author = "Kristin Hannah",
                ISBN = "9780312577221",
                PublishedDate = new DateTime(2015, 2, 3),
                Category = "Historical Fiction",
                TotalCopies = 11,
                AvailableCopies = 11,
                CoverImageUrl = "https://th.bing.com/th/id/OIP.ymyFxrYUmIJK8wJNWVZJ-wAAAA?rs=1&pid=ImgDetMain"
            });

            Books.Add(new Book
            {
                BookId = 34,
                Title = "Big Little Lies",
                Author = "Liane Moriarty",
                ISBN = "9780399167065",
                PublishedDate = new DateTime(2014, 7, 29),
                Category = "Mystery",
                TotalCopies = 8,
                AvailableCopies = 8,
                CoverImageUrl = "https://i0.wp.com/candidcover.net/wp-content/uploads/91hxAg7WaL.jpg?fit=1403%2C2475&ssl=1"
            });

            Books.Add(new Book
            {
                BookId = 35,
                Title = "The Woman in the Window",
                Author = "A.J. Finn",
                ISBN = "9780062678416",
                PublishedDate = new DateTime(2018, 1, 2),
                Category = "Thriller",
                TotalCopies = 7,
                AvailableCopies = 7,
                CoverImageUrl = "https://th.bing.com/th/id/OIP.k6xSsyW9R9GLdEnaDIxbTQAAAA?rs=1&pid=ImgDetMain"
            });

            Books.Add(new Book
            {
                BookId = 36,
                Title = "The Help",
                Author = "Kathryn Stockett",
                ISBN = "9780399155345",
                PublishedDate = new DateTime(2009, 2, 10),
                Category = "Historical Fiction",
                TotalCopies = 12,
                AvailableCopies = 12,
                CoverImageUrl = "https://th.bing.com/th/id/OIP.RHG-0HxD8rijQqNWi3isUAHaLC?rs=1&pid=ImgDetMain"
            });

            Books.Add(new Book
            {
                BookId = 37,
                Title = "Where the Crawdads Sing",
                Author = "Delia Owens",
                ISBN = "9780735219090",
                PublishedDate = new DateTime(2018, 8, 14),
                Category = "Fiction",
                TotalCopies = 14,
                AvailableCopies = 14,
                CoverImageUrl = "https://images-na.ssl-images-amazon.com/images/I/51VG7wnnj0L._SY346_.jpg"
            });

            Books.Add(new Book
            {
                BookId = 38,
                Title = "Educated",
                Author = "Tara Westover",
                ISBN = "9780399590504",
                PublishedDate = new DateTime(2018, 2, 20),
                Category = "Biography",
                TotalCopies = 10,
                AvailableCopies = 10,
                CoverImageUrl = "https://th.bing.com/th/id/OIP.Jg5Zkjii8xXlqw6FYJ-ymwHaJS?rs=1&pid=ImgDetMain"
            });

            Books.Add(new Book
            {
                BookId = 39,
                Title = "Sapiens: A Brief History of Humankind",
                Author = "Yuval Noah Harari",
                ISBN = "9780062316097",
                PublishedDate = new DateTime(2015, 9, 4),
                Category = "Non-fiction",
                TotalCopies = 13,
                AvailableCopies = 13,
                CoverImageUrl = "https://d30a6s96kk7rhm.cloudfront.net/original/readings/978/009/959/9780099590088.jpg"
            });

            Books.Add(new Book
            {
                BookId = 40,
                Title = "Becoming",
                Author = "Michelle Obama",
                ISBN = "9781524763138",
                PublishedDate = new DateTime(2018, 11, 13),
                Category = "Biography",
                TotalCopies = 15,
                AvailableCopies = 15,
                CoverImageUrl = "https://images.thenile.io/r1000/9780241531815.jpg"
            });



            // Adding sample BorrowingRecords
            BorrowingRecords.Add(new BorrowingRecord
            {
                BorrowId = 1,
                BookId = 1,
                PatronId = 1,
                BorrowDate = DateTime.Now.AddDays(-10),
                DueDate = DateTime.Now.AddDays(5),
                Status = BorrowingStatus.Borrowed
            });

            BorrowingRecords.Add(new BorrowingRecord
            {
                BorrowId = 2,
                BookId = 2,
                PatronId = 2,
                BorrowDate = DateTime.Now.AddDays(-2),
                DueDate = DateTime.Now.AddDays(10),
                Status = BorrowingStatus.Borrowed
            });

            // Adding more sample BorrowingRecords
            BorrowingRecords.Add(new BorrowingRecord
            {
                BorrowId = 3,
                BookId = 3, // Assume Book with ID 3 exists
                PatronId = 3, // Patron with ID 3
                BorrowDate = DateTime.Now.AddDays(-15),
                DueDate = DateTime.Now.AddDays(-5),
                Status = BorrowingStatus.Overdue // Overdue record
            });

            BorrowingRecords.Add(new BorrowingRecord
            {
                BorrowId = 4,
                BookId = 4, // Assume Book with ID 4 exists
                PatronId = 4, // Patron with ID 4
                BorrowDate = DateTime.Now.AddDays(-3),
                DueDate = DateTime.Now.AddDays(7),
                Status = BorrowingStatus.Borrowed
            });

            BorrowingRecords.Add(new BorrowingRecord
            {
                BorrowId = 5,
                BookId = 5, // Assume Book with ID 5 exists
                PatronId = 5, // Patron with ID 5
                BorrowDate = DateTime.Now.AddDays(-20),
                DueDate = DateTime.Now.AddDays(-10),
                Status = BorrowingStatus.Returned // Book has been returned
            });

            BorrowingRecords.Add(new BorrowingRecord
            {
                BorrowId = 6,
                BookId = 6, // Assume Book with ID 6 exists
                PatronId = 6, // Patron with ID 6
                BorrowDate = DateTime.Now.AddDays(-7),
                DueDate = DateTime.Now.AddDays(3),
                Status = BorrowingStatus.Borrowed
            });

            BorrowingRecords.Add(new BorrowingRecord
            {
                BorrowId = 7,
                BookId = 7, // Assume Book with ID 7 exists
                PatronId = 7, // Patron with ID 7
                BorrowDate = DateTime.Now.AddDays(-5),
                DueDate = DateTime.Now.AddDays(5),
                Status = BorrowingStatus.Borrowed
            });

            BorrowingRecords.Add(new BorrowingRecord
            {
                BorrowId = 8,
                BookId = 6, // Assume Book with ID 8 exists
                PatronId = 8, // Patron with ID 8
                BorrowDate = DateTime.Now.AddDays(-30),
                DueDate = DateTime.Now.AddDays(-20),
                Status = BorrowingStatus.Overdue // Overdue record
            });

            BorrowingRecords.Add(new BorrowingRecord
            {
                BorrowId = 9,
                BookId = 3, // Assume Book with ID 9 exists
                PatronId = 9, // Patron with ID 9
                BorrowDate = DateTime.Now.AddDays(-1),
                DueDate = DateTime.Now.AddDays(14),
                Status = BorrowingStatus.Borrowed
            });

            BorrowingRecords.Add(new BorrowingRecord
            {
                BorrowId = 10,
                BookId = 1, // Assume Book with ID 10 exists
                PatronId = 10, // Patron with ID 10
                BorrowDate = DateTime.Now.AddDays(-40),
                DueDate = DateTime.Now.AddDays(-30),
                Status = BorrowingStatus.Returned
            });

            BorrowingRecords.Add(new BorrowingRecord
            {
                BorrowId = 11,
                BookId = 3, // Repeated book with another Patron
                PatronId = 11, // Patron with ID 11
                BorrowDate = DateTime.Now.AddDays(-4),
                DueDate = DateTime.Now.AddDays(6),
                Status = BorrowingStatus.Borrowed
            });

            BorrowingRecords.Add(new BorrowingRecord
            {
                BorrowId = 12,
                BookId = 4, // Repeated book with another Patron
                PatronId = 12, // Patron with ID 12
                BorrowDate = DateTime.Now.AddDays(-12),
                DueDate = DateTime.Now.AddDays(-2),
                Status = BorrowingStatus.Overdue
            });

        }
    }
}
