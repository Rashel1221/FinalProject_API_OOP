﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using MySql.Data.MySqlClient;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using LibraryBookTracker_FinalProject.Model;
using LibraryBookTracker_FinalProject.Model.DTO;

namespace LibraryBookTracker_FinalProject.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class LibrarianController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        private const string Salt = ")GN#447#^nryrETNwrbR%#&NBRE%#%BBDT#%";

        public LibrarianController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        private string ConnectionString => _configuration.GetConnectionString("DefaultConnection");

        [HttpPost("Login")]
        public ActionResult Login([FromBody] LogInDTO loginDto)
        {
            string hashedPassword = HashPassword(loginDto.Password);

            using (var connection = new MySqlConnection(ConnectionString))
            {
                connection.Open();
                string query = "SELECT * FROM Librarians WHERE Username = @Username AND Password = @Password";

                using (var command = new MySqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Username", loginDto.Username);
                    command.Parameters.AddWithValue("@Password", hashedPassword);

                    using (var reader = command.ExecuteReader())
                    {
                        if (!reader.Read())
                        {
                            return Unauthorized("Invalid login credentials.");
                        }

                        var librarian = new Librarian
                        {
                            LibrarianId = Convert.ToInt32(reader["LibrarianId"]),
                            Username = reader["Username"].ToString(),
                            Email = reader["Email"].ToString(),
                            Role = reader["Role"].ToString() // Ensure that the role is fetched from the database
                        };

                        var token = GenerateJwtToken(librarian, loginDto.Platform);
                        return Ok(new { Token = token, Message = "Login successful." });
                    }
                }
            }
        }

        [HttpPost("Register")]
        public ActionResult Register([FromBody] Librarian newLibrarian)
        {
            string hashedPassword = HashPassword(newLibrarian.Password);

            try
            {
                using (var connection = new MySqlConnection(ConnectionString))
                {
                    connection.Open();

                    string checkQuery = "SELECT COUNT(*) FROM Librarians WHERE Email = @Email";
                    using (var checkCommand = new MySqlCommand(checkQuery, connection))
                    {
                        checkCommand.Parameters.AddWithValue("@Email", newLibrarian.Email);

                        var count = Convert.ToInt32(checkCommand.ExecuteScalar());
                        if (count > 0)
                        {
                            return BadRequest("Email is already registered. Please choose a different one.");
                        }
                    }

                    string insertQuery = "INSERT INTO Librarians (Username, FirstName, LastName, Email, Password, Role) VALUES (@Username, @FirstName, @LastName, @Email, @Password, @Role)";
                    using (var insertCommand = new MySqlCommand(insertQuery, connection))
                    {
                        insertCommand.Parameters.AddWithValue("@Username", newLibrarian.Username);
                        insertCommand.Parameters.AddWithValue("@FirstName", newLibrarian.FirstName);
                        insertCommand.Parameters.AddWithValue("@LastName", newLibrarian.LastName);
                        insertCommand.Parameters.AddWithValue("@Email", newLibrarian.Email);
                        insertCommand.Parameters.AddWithValue("@Role", newLibrarian.Role); // Ensure the Role is inserted
                        insertCommand.Parameters.AddWithValue("@Password", hashedPassword);

                        insertCommand.ExecuteNonQuery();
                    }
                }

                return Ok("Registered successfully.");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpPut("UpdateProfile/{id}")]
        [Authorize(Roles = "librarian")]
        public ActionResult UpdateProfile(int id, [FromBody] Librarian updatedLibrarian)
        {
            using (var connection = new MySqlConnection(ConnectionString))
            {
                connection.Open();

                string query = "UPDATE Librarians SET Email = @Email" +
                               (string.IsNullOrEmpty(updatedLibrarian.Password) ? "" : ", Password = @Password") +
                               " WHERE LibrarianId = @LibrarianId";

                using (var command = new MySqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Email", updatedLibrarian.Email);
                    command.Parameters.AddWithValue("@LibrarianId", id);

                    if (!string.IsNullOrEmpty(updatedLibrarian.Password))
                    {
                        command.Parameters.AddWithValue("@Password", HashPassword(updatedLibrarian.Password));
                    }

                    int rowsAffected = command.ExecuteNonQuery();
                    if (rowsAffected == 0)
                    {
                        return NotFound("Librarian not found.");
                    }
                }
            }

            return Ok("Profile updated successfully.");
        }

        [HttpGet("GetAllLibrarians")]
        [Authorize(Roles = "librarian")] // Only accessible by librarians
        public ActionResult<IEnumerable<Librarian>> GetAllLibrarians()
        {
            var librarians = new List<Librarian>();

            using (var connection = new MySqlConnection(ConnectionString))
            {
                connection.Open();
                string query = "SELECT * FROM Librarians";

                using (var command = new MySqlCommand(query, connection))
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        librarians.Add(new Librarian
                        {
                            LibrarianId = Convert.ToInt32(reader["LibrarianId"]),
                            Username = reader["Username"].ToString(),
                            Email = reader["Email"].ToString(),
                        });
                    }
                }
            }

            return Ok(librarians);
        }

        [HttpGet("GetLibrarian/{id}")]
        [Authorize(Roles = "librarian")] // Only accessible by librarians
        public ActionResult<Librarian> GetLibrarian(int id)
        {
            using (var connection = new MySqlConnection(ConnectionString))
            {
                connection.Open();
                string query = "SELECT * FROM Librarians WHERE LibrarianId = @LibrarianId";

                using (var command = new MySqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@LibrarianId", id);

                    using (var reader = command.ExecuteReader())
                    {
                        if (!reader.Read())
                        {
                            return NotFound("Librarian not found.");
                        }

                        var librarian = new Librarian
                        {
                            LibrarianId = Convert.ToInt32(reader["LibrarianId"]),
                            Username = reader["Username"].ToString(),
                            Email = reader["Email"].ToString(),
                        };

                        return Ok(librarian);
                    }
                }
            }
        }

        private string GenerateJwtToken(Librarian librarian, string platform)
        {
            var claims = new[]
            {
        new Claim(JwtRegisteredClaimNames.Sub, librarian.Email),
        new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
        new Claim("LibrarianId", librarian.LibrarianId.ToString()),
        new Claim("Platform", platform),
        new Claim(ClaimTypes.Role, librarian.Role)  // Ensure Role is included in the claims
    };

            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["JwtSettings:Key"]));
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var token = new JwtSecurityToken(
                _configuration["JwtSettings:Issuer"],
                _configuration["JwtSettings:Audience"],
                claims,
                expires: DateTime.Now.AddMinutes(Convert.ToDouble(_configuration["JwtSettings:ExpiryMinutes"])),
                signingCredentials: creds);

            return new JwtSecurityTokenHandler().WriteToken(token);
        }


        private string HashPassword(string password)
        {
            using (var sha256 = SHA256.Create())
            {
                var saltedPassword = Salt + password;
                var hashBytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(saltedPassword));
                return BitConverter.ToString(hashBytes).Replace("-", "").ToLower();
            }
        }
    }
}
