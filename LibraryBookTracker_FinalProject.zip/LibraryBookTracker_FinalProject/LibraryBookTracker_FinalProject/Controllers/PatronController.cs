﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using MySql.Data.MySqlClient;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using LibraryBookTracker_FinalProject.Model;
using LibraryBookTracker_FinalProject.Model.DTO;
using Microsoft.AspNetCore.Authorization;

namespace LibraryBookTracker_FinalProject.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class MembersController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        private const string Salt = ")GN#447#^nryrETNwrbR%#&NBRE%#%BBDT#%";

        public MembersController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        private string ConnectionString => _configuration.GetConnectionString("DefaultConnection");

        // Register member
        [HttpPost("Register")]
        public async Task<ActionResult> Register([FromForm] Patron newMember, IFormFile profilePic)
        {
            if (newMember == null || string.IsNullOrEmpty(newMember.FirstName) || string.IsNullOrEmpty(newMember.LastName) ||
                string.IsNullOrEmpty(newMember.Email) || string.IsNullOrEmpty(newMember.Username) || string.IsNullOrEmpty(newMember.Password))
            {
                return BadRequest("Invalid member data.");
            }

            // Hash the password
            string hashedPassword = HashPassword(newMember.Password);

            // Directory for saving profile pictures
            var uploads = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "images");
            if (!Directory.Exists(uploads))
            {
                Directory.CreateDirectory(uploads);
            }

            string profilePicPath = null;

            if (profilePic != null)
            {
                // Handle file name collision
                string fileName = Path.GetFileNameWithoutExtension(profilePic.FileName);
                string fileExtension = Path.GetExtension(profilePic.FileName);
                string uniqueFileName = $"{fileName}_{Guid.NewGuid()}{fileExtension}";

                profilePicPath = Path.Combine(uploads, uniqueFileName);

                // Save the profile picture
                using (var stream = new FileStream(profilePicPath, FileMode.Create))
                {
                    await profilePic.CopyToAsync(stream);
                }
            }

            try
            {
                using (var connection = new MySqlConnection(ConnectionString))
                {
                    connection.Open();

                    // Check if email already exists
                    string checkEmailQuery = "SELECT COUNT(*) FROM Patrons WHERE Email = @Email";
                    using (var checkEmailCommand = new MySqlCommand(checkEmailQuery, connection))
                    {
                        checkEmailCommand.Parameters.AddWithValue("@Email", newMember.Email);
                        var emailCount = Convert.ToInt32(checkEmailCommand.ExecuteScalar());

                        if (emailCount > 0)
                        {
                            return BadRequest("Email is already registered. Please choose a different one.");
                        }
                    }

                    // Insert new member into the database
                    string insertQuery = "INSERT INTO Patrons (FirstName, LastName, Email, PhoneNumber, JoinDate, Username, Password, Role, ProfilePicture) " +
                                         "VALUES (@FirstName, @LastName, @Email, @PhoneNumber, @JoinDate, @Username, @Password, @Role, @ProfilePic)";

                    using (var insertCommand = new MySqlCommand(insertQuery, connection))
                    {
                        insertCommand.Parameters.AddWithValue("@FirstName", newMember.FirstName);
                        insertCommand.Parameters.AddWithValue("@LastName", newMember.LastName);
                        insertCommand.Parameters.AddWithValue("@Email", newMember.Email);
                        insertCommand.Parameters.AddWithValue("@PhoneNumber", newMember.PhoneNumber ?? string.Empty); // Handle null phone number
                        insertCommand.Parameters.AddWithValue("@JoinDate", DateTime.Now); // Set current date as join date
                        insertCommand.Parameters.AddWithValue("@Username", newMember.Username);
                        insertCommand.Parameters.AddWithValue("@Role", newMember.Role ?? "User"); // Set default role to "User" if null
                        insertCommand.Parameters.AddWithValue("@Password", hashedPassword);
                        insertCommand.Parameters.AddWithValue("@ProfilePic", profilePicPath ?? string.Empty); // Insert the profile picture path or an empty string

                        insertCommand.ExecuteNonQuery();
                    }
                }

                return Ok("Member registered successfully.");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        // Login member
        [HttpPost("Login")]
        public ActionResult Login([FromBody] LogInDTO loginDto)
        {
            if (loginDto == null || string.IsNullOrEmpty(loginDto.Username) || string.IsNullOrEmpty(loginDto.Password))
            {
                return BadRequest("Invalid login credentials.");
            }

            string hashedPassword = HashPassword(loginDto.Password);

            try
            {
                using (var connection = new MySqlConnection(ConnectionString))
                {
                    connection.Open();
                    string query = "SELECT * FROM Patrons WHERE Username = @Username AND Password = @Password";

                    using (var command = new MySqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@Username", loginDto.Username);
                        command.Parameters.AddWithValue("@Password", hashedPassword);

                        using (var reader = command.ExecuteReader())
                        {
                            if (!reader.Read())
                            {
                                return Unauthorized("Invalid login credentials.");
                            }

                            var patron = new Patron
                            {
                                PatronsId = Convert.ToInt32(reader["PatronsId"]),
                                FirstName = reader["FirstName"].ToString(),
                                LastName = reader["LastName"].ToString(),
                                Email = reader["Email"].ToString(),
                                PhoneNumber = reader["PhoneNumber"].ToString(),
                                JoinDate = Convert.ToDateTime(reader["JoinDate"]),
                                Username = reader["Username"].ToString(),
                                Role = reader["Role"].ToString(),
                                ProfilePic = reader["ProfilePicture"].ToString()
                            };

                            var token = GenerateJwtToken(patron, loginDto.Platform);
                            return Ok(new { Token = token, Id = patron.PatronsId, Message = "Login successful." });
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        // Get all members
        [HttpGet]
        [Authorize]
        public ActionResult<IEnumerable<Patron>> GetAllMembers()
        {
            var patrons = new List<Patron>();

            using (var connection = new MySqlConnection(ConnectionString))
            {
                connection.Open();
                string query = "SELECT * FROM Patrons";

                using (var command = new MySqlCommand(query, connection))
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        patrons.Add(new Patron
                        {
                            PatronsId = Convert.ToInt32(reader["PatronsId"]),
                            FirstName = reader["FirstName"].ToString(),
                            LastName = reader["LastName"].ToString(),
                            Email = reader["Email"].ToString(),
                            PhoneNumber = reader["PhoneNumber"].ToString(),
                            JoinDate = Convert.ToDateTime(reader["JoinDate"]),
                            Username = reader["Username"].ToString(),
                            Role = reader["Role"].ToString(),
                            ProfilePic = reader["ProfilePicture"].ToString()
                        });
                    }
                }
            }

            return Ok(patrons);
        }

        // Get member by ID
        [HttpGet("{memberId}")]
        [Authorize]
        public ActionResult<Patron> GetMemberById(int memberId)
        {
            Console.WriteLine($"Attempting to get member with ID: {memberId}");  // Debug log

            using (var connection = new MySqlConnection(ConnectionString))
            {
                connection.Open();
                string query = "SELECT * FROM Patrons WHERE PatronsId = @PatronsId";

                using (var command = new MySqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@PatronsId", memberId);

                    using (var reader = command.ExecuteReader())
                    {
                        if (!reader.Read())
                        {
                            Console.WriteLine("No member found.");  // Debug log
                            return NotFound("Member not found.");
                        }

                        var patron = new Patron
                        {
                            PatronsId = Convert.ToInt32(reader["PatronsId"]),
                            FirstName = reader["FirstName"].ToString(),
                            LastName = reader["LastName"].ToString(),
                            Email = reader["Email"].ToString(),
                            PhoneNumber = reader["PhoneNumber"].ToString(),
                            JoinDate = Convert.ToDateTime(reader["JoinDate"]),
                            Username = reader["Username"].ToString(),
                            Role = reader["Role"].ToString(),
                            ProfilePic = reader["ProfilePicture"].ToString()
                        };

                        return Ok(patron);
                    }
                }
            }
        }
        // Update member details
        [HttpPut("{memberId}")]
        public async Task<ActionResult> UpdateMember(int memberId, [FromForm] Patron updatedMember, IFormFile profilePic)
        {
            try
            {
                string profilePicPath = updatedMember.ProfilePic;  // Keep the old profile picture URL if no new image is uploaded

                // If a new profile picture is uploaded, process it
                if (profilePic != null)
                {
                    string filePath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "images");
                    if (!Directory.Exists(filePath))
                    {
                        Directory.CreateDirectory(filePath);
                    }

                   

                    if (profilePic != null)
                    {
                        // Handle file name collision
                        string fileName = Path.GetFileNameWithoutExtension(profilePic.FileName);
                        string fileExtension = Path.GetExtension(profilePic.FileName);
                        string uniqueFileName = $"{fileName}_{Guid.NewGuid()}{fileExtension}";

                        profilePicPath = Path.Combine(filePath, uniqueFileName);

                        // Save the profile picture
                        using (var stream = new FileStream(profilePicPath, FileMode.Create))
                        {
                            await profilePic.CopyToAsync(stream);
                        }
                    }
                }

                using (var connection = new MySqlConnection(ConnectionString))
                {
                    connection.Open();
                    string query = "UPDATE Patrons SET FirstName = @FirstName, LastName = @LastName, Email = @Email, " +
                                   "PhoneNumber = @PhoneNumber, ProfilePicture = @ProfilePic WHERE PatronsId = @PatronsId";

                    using (var command = new MySqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@PatronsId", memberId);
                        command.Parameters.AddWithValue("@FirstName", updatedMember.FirstName);
                        command.Parameters.AddWithValue("@LastName", updatedMember.LastName);
                        command.Parameters.AddWithValue("@Email", updatedMember.Email);
                        command.Parameters.AddWithValue("@PhoneNumber", updatedMember.PhoneNumber);
                        command.Parameters.AddWithValue("@ProfilePic", profilePicPath ?? string.Empty);  // Store the new profile picture path

                        int rowsAffected = command.ExecuteNonQuery();
                        if (rowsAffected == 0)
                        {
                            return NotFound("Member not found.");
                        }
                    }
                }

                return Ok("Patron updated successfully.");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }
        // Delete member by ID
        [HttpDelete("{memberId}")]
        [Authorize]
        public ActionResult DeleteMember(int memberId)
        {
            try
            {
                using (var connection = new MySqlConnection(ConnectionString))
                {
                    connection.Open();
                    string query = "DELETE FROM Patrons WHERE PatronsId = @PatronsId";

                    using (var command = new MySqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@PatronsId", memberId);

                        int rowsAffected = command.ExecuteNonQuery();
                        if (rowsAffected == 0)
                        {
                            return NotFound("Member not found.");
                        }
                    }
                }

                return Ok("Member deleted successfully.");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        private string GenerateJwtToken(Patron patron, string platform)
        {
            var claims = new[]
            {
                new Claim(JwtRegisteredClaimNames.Sub, patron.Email),
                new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
                new Claim("PatronsId", patron.PatronsId.ToString()), // Include PatronsId
                new Claim("Platform", platform),
                new Claim(ClaimTypes.Role, patron.Role)  // Ensure Role is included in the claims
            };

            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["JwtSettings:Key"]));
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var token = new JwtSecurityToken(
                _configuration["JwtSettings:Issuer"],
                _configuration["JwtSettings:Audience"],
                claims,
                expires: DateTime.Now.AddMinutes(Convert.ToDouble(_configuration["JwtSettings:ExpiryMinutes"])),
                signingCredentials: creds);

            return new JwtSecurityTokenHandler().WriteToken(token);
        }

        private string HashPassword(string password)
        {
            using (var sha256 = SHA256.Create())
            {
                var saltedPassword = Salt + password;
                var hashBytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(saltedPassword));
                return BitConverter.ToString(hashBytes).Replace("-", "").ToLower();
            }
        }
    }
}
