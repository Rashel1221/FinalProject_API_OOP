﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using MySql.Data.MySqlClient;
using LibraryBookTracker_FinalProject.Model;
using System;
using System.Collections.Generic;
using System.Linq;

namespace LibraryBookTracker_FinalProject.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize] // Require authentication for all endpoints
    public class BorrowingRecordController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        private string ConnectionString => _configuration.GetConnectionString("DefaultConnection");

        public BorrowingRecordController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        // POST: /borrow-records (Submit Borrowing Request)
        [HttpPost]
        [Authorize] // Ensure only authenticated users can access
        public ActionResult AddBorrowingRecord([FromBody] BorrowingRecord record)
        {
            // Extract Patron ID from the JWT
            var patronIdClaim = User.Claims.FirstOrDefault(c => c.Type == "PatronsId");
            if (patronIdClaim == null)
            {
                return Unauthorized("User is not authenticated.");
            }

            int authenticatedPatronId = int.Parse(patronIdClaim.Value);

            // Check if the patron ID in the request matches the authenticated Patron ID
            if (record.PatronId != authenticatedPatronId)
            {
                return Forbid("You can only borrow books for your account.");
            }

            if (record.BookId <= 0 || record.BorrowDate == DateTime.MinValue || record.DueDate == DateTime.MinValue)
            {
                return BadRequest("Invalid borrowing record data.");
            }

            // Validate Book
            var book = GetBookById(record.BookId);
            if (book == null)
            {
                return NotFound($"Book with ID {record.BookId} not found.");
            }

            // Check Book Availability
            if (book.AvailableCopies <= 0)
            {
                return BadRequest("No available copies for this book.");
            }

            // Create the Borrowing Record
            try
            {
                record.Status = BorrowingStatus.PendingApproval; // Set initial status as PendingApproval
                using (var connection = new MySqlConnection(ConnectionString))
                {
                    connection.Open();
                    string query = "INSERT INTO BorrowingRecords (BookId, PatronId, BorrowDate, DueDate, Status) VALUES (@BookId, @PatronId, @BorrowDate, @DueDate, @Status)";

                    using (var command = new MySqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@BookId", record.BookId);
                        command.Parameters.AddWithValue("@PatronId", authenticatedPatronId); // Use authenticated Patron ID
                        command.Parameters.AddWithValue("@BorrowDate", record.BorrowDate);
                        command.Parameters.AddWithValue("@DueDate", record.DueDate);
                        command.Parameters.AddWithValue("@Status", (int)record.Status);

                        command.ExecuteNonQuery();
                    }
                }

                return Ok("Borrowing request submitted successfully and is pending librarian approval.");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        // GET: /borrow-records (Get All Borrowing Records)
        [HttpGet]
        public ActionResult<IEnumerable<BorrowingRecord>> GetAllBorrowingRecords()
        {
            var records = new List<BorrowingRecord>();

            using (var connection = new MySqlConnection(ConnectionString))
            {
                connection.Open();
                string query = "SELECT * FROM BorrowingRecords";

                using (var command = new MySqlCommand(query, connection))
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        records.Add(new BorrowingRecord
                        {
                            BorrowId = Convert.ToInt32(reader["BorrowId"]),
                            BookId = Convert.ToInt32(reader["BookId"]),
                            PatronId = Convert.ToInt32(reader["PatronId"]),
                            BorrowDate = Convert.ToDateTime(reader["BorrowDate"]),
                            DueDate = Convert.ToDateTime(reader["DueDate"]),
                            ReturnDate = reader["ReturnDate"] as DateTime?,
                            Status = (BorrowingStatus)Convert.ToInt32(reader["Status"]),
                        });
                    }
                }
            }

            return Ok(records);
        }

        // PUT: /borrow-records/{borrow_id}/approve (Approve Borrowing Request)
        [HttpPut("approve/{borrowId}")]
        [Authorize(Roles = "librarian")] // Ensure only librarians can approve
        public ActionResult ApproveBorrowRequest(int borrowId)
        {
            var record = GetBorrowingRecordById(borrowId);
            if (record == null) return NotFound($"Borrowing record with ID {borrowId} not found.");

            if (record.Status != BorrowingStatus.PendingApproval)
            {
                return BadRequest("Only requests with PendingApproval status can be approved.");
            }

            try
            {
                using (var connection = new MySqlConnection(ConnectionString))
                {
                    connection.Open();
                    string query = "UPDATE BorrowingRecords SET Status = @Status WHERE BorrowId = @BorrowId";

                    using (var command = new MySqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@Status", (int)BorrowingStatus.Borrowed);
                        command.Parameters.AddWithValue("@BorrowId", borrowId);

                        command.ExecuteNonQuery();
                    }
                }

                // Update Book's Available Copies
                UpdateBookAvailability(record.BookId, -1);

                return Ok("Borrowing request approved successfully.");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        // PUT: /borrow-records/{borrow_id}/reject (Reject Borrowing Request)
        [HttpPut("reject/{borrowId}")]
        [Authorize(Roles = "librarian")] // Ensure only librarians can reject
        public ActionResult RejectBorrowRequest(int borrowId)
        {
            var record = GetBorrowingRecordById(borrowId);
            if (record == null) return NotFound($"Borrowing record with ID {borrowId} not found.");

            if (record.Status != BorrowingStatus.PendingApproval)
            {
                return BadRequest("Only requests with PendingApproval status can be rejected.");
            }

            try
            {
                using (var connection = new MySqlConnection(ConnectionString))
                {
                    connection.Open();
                    string query = "UPDATE BorrowingRecords SET Status = @Status WHERE BorrowId = @BorrowId";

                    using (var command = new MySqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@Status", (int)BorrowingStatus.Rejected);
                        command.Parameters.AddWithValue("@BorrowId", borrowId);

                        command.ExecuteNonQuery();
                    }
                }

                return Ok("Borrowing request rejected successfully.");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        // GET: /borrow-records/pending-requests (Get Pending Borrowing Requests)
        [HttpGet("pending-requests")]
        [Authorize(Roles = "librarian")] // Ensure only librarians can view pending requests
        public ActionResult<IEnumerable<BorrowingRecord>> GetPendingRequests()
        {
            var records = new List<BorrowingRecord>();

            using (var connection = new MySqlConnection(ConnectionString))
            {
                connection.Open();
                string query = "SELECT * FROM BorrowingRecords WHERE Status = @Status";

                using (var command = new MySqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Status", (int)BorrowingStatus.PendingApproval);

                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            records.Add(new BorrowingRecord
                            {
                                BorrowId = Convert.ToInt32(reader["BorrowId"]),
                                BookId = Convert.ToInt32(reader["BookId"]),
                                PatronId = Convert.ToInt32(reader["PatronId"]),
                                BorrowDate = Convert.ToDateTime(reader["BorrowDate"]),
                                DueDate = Convert.ToDateTime(reader["DueDate"]),
                                Status = (BorrowingStatus)Convert.ToInt32(reader["Status"])
                            });
                        }
                    }
                }
            }

            return Ok(records);
        }
        [HttpPut("return/{borrowId}")]
        public ActionResult ReturnBook(int borrowId)
        {
            try
            {
                // Retrieve the borrowing record
                var record = GetBorrowingRecordById(borrowId);
                if (record == null)
                {
                    return NotFound($"Borrowing record with ID {borrowId} not found.");
                }

                // Ensure the patron is returning their own borrowed book
                var patronIdClaim = User.Claims.FirstOrDefault(c => c.Type == "PatronsId");
                if (patronIdClaim == null)
                {
                    return Unauthorized("User is not authenticated.");
                }

                int authenticatedPatronId = int.Parse(patronIdClaim.Value);
                if (record.PatronId != authenticatedPatronId)
                {
                    return Forbid("You can only return books borrowed by your account.");
                }

                // Check if the book has already been returned
                if (record.ReturnDate.HasValue)
                {
                    return BadRequest("This book has already been returned.");
                }

                // Update the borrowing record to reflect the book's return
                using (var connection = new MySqlConnection(ConnectionString))
                {
                    connection.Open();
                    string query = "UPDATE BorrowingRecords SET ReturnDate = @ReturnDate, Status = @Status WHERE BorrowId = @BorrowId";

                    using (var command = new MySqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@ReturnDate", DateTime.Now);
                        command.Parameters.AddWithValue("@Status", (int)BorrowingStatus.Returned);
                        command.Parameters.AddWithValue("@BorrowId", borrowId);

                        int rowsAffected = command.ExecuteNonQuery();
                        if (rowsAffected == 0)
                        {
                            return NotFound("Failed to update borrowing record.");
                        }
                    }
                }

                // Update Book's Available Copies
                UpdateBookAvailability(record.BookId, 1);

                // Get book details for the response
                var book = GetBookById(record.BookId);
                if (book == null)
                {
                    return NotFound($"Book with ID {record.BookId} not found.");
                }

                // Return a detailed response with the book title, return date, and status
                var response = new
                {
                    Message = "Book returned successfully.",
                    BookTitle = book.Title,
                    ReturnDate = DateTime.Now,
                    Status = BorrowingStatus.Returned.ToString()
                };

                return Ok(response);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }
        [HttpGet("GetByBookId/{bookId}")]
        public ActionResult<IEnumerable<BorrowingRecord>> GetBorrowingRecordsByBookId(int bookId)
        {
            var records = new List<BorrowingRecord>();

            using (var connection = new MySqlConnection(ConnectionString))
            {
                connection.Open();
                string query = "SELECT * FROM BorrowingRecords WHERE BookId = @BookId";

                using (var command = new MySqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@BookId", bookId);

                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            records.Add(new BorrowingRecord
                            {
                                BorrowId = Convert.ToInt32(reader["BorrowId"]),
                                BookId = Convert.ToInt32(reader["BookId"]),
                                PatronId = Convert.ToInt32(reader["PatronId"]),
                                BorrowDate = Convert.ToDateTime(reader["BorrowDate"]),
                                DueDate = Convert.ToDateTime(reader["DueDate"]),
                                ReturnDate = reader["ReturnDate"] as DateTime?,
                                Status = (BorrowingStatus)Convert.ToInt32(reader["Status"])
                            });
                        }
                    }
                }
            }

            if (!records.Any())
            {
                return NotFound("No borrowing records found for this book.");
            }

            return Ok(records);
        }

        private Book GetBookById(int bookId)
        {
            using (var connection = new MySqlConnection(ConnectionString))
            {
                connection.Open();
                string query = "SELECT * FROM Books WHERE BookId = @BookId";

                using (var command = new MySqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@BookId", bookId);
                    using (var reader = command.ExecuteReader())
                    {
                        if (!reader.Read())
                            return null;

                        return new Book
                        {
                            BookId = Convert.ToInt32(reader["BookId"]),
                            Title = reader["Title"].ToString(),
                            Author = reader["Author"].ToString(),
                            ISBN = reader["ISBN"].ToString(),
                            PublishedDate = reader["PublishedDate"] as DateTime?,
                            Category = reader["Category"].ToString(),
                            TotalCopies = Convert.ToInt32(reader["TotalCopies"]),
                            AvailableCopies = Convert.ToInt32(reader["AvailableCopies"]),
                        };
                    }
                }
            }
        }

        private BorrowingRecord GetBorrowingRecordById(int borrowId)
        {
            using (var connection = new MySqlConnection(ConnectionString))
            {
                connection.Open();
                string query = "SELECT * FROM BorrowingRecords WHERE BorrowId = @BorrowId";

                using (var command = new MySqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@BorrowId", borrowId);
                    using (var reader = command.ExecuteReader())
                    {
                        if (!reader.Read())
                            return null;

                        return new BorrowingRecord
                        {
                            BorrowId = Convert.ToInt32(reader["BorrowId"]),
                            BookId = Convert.ToInt32(reader["BookId"]),
                            PatronId = Convert.ToInt32(reader["PatronId"]),
                            BorrowDate = Convert.ToDateTime(reader["BorrowDate"]),
                            DueDate = Convert.ToDateTime(reader["DueDate"]),
                            ReturnDate = reader["ReturnDate"] as DateTime?,
                            Status = (BorrowingStatus)Convert.ToInt32(reader["Status"]),
                        };
                    }
                }
            }
        }

        private void UpdateBookAvailability(int bookId, int change)
        {
            using (var connection = new MySqlConnection(ConnectionString))
            {
                connection.Open();
                string query = "UPDATE Books SET AvailableCopies = AvailableCopies + @Change WHERE BookId = @BookId";

                using (var command = new MySqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Change", change);
                    command.Parameters.AddWithValue("@BookId", bookId);

                    command.ExecuteNonQuery();
                }
            }
        }
        // GET: /borrow-records/patron/{patronId} (Get Borrowing Records by Patron ID)
        [HttpGet("patron/{patronId}")]
        public ActionResult<IEnumerable<BorrowingRecord>> GetBorrowingRecordsByPatronId(int patronId)
        {
            var records = new List<BorrowingRecord>();

            using (var connection = new MySqlConnection(ConnectionString))
            {
                connection.Open();
                string query = "SELECT * FROM BorrowingRecords WHERE PatronId = @PatronId";

                using (var command = new MySqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@PatronId", patronId);

                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            records.Add(new BorrowingRecord
                            {
                                BorrowId = Convert.ToInt32(reader["BorrowId"]),
                                BookId = Convert.ToInt32(reader["BookId"]),
                                PatronId = Convert.ToInt32(reader["PatronId"]),
                                BorrowDate = Convert.ToDateTime(reader["BorrowDate"]),
                                DueDate = Convert.ToDateTime(reader["DueDate"]),
                                ReturnDate = reader["ReturnDate"] as DateTime?,
                                Status = (BorrowingStatus)Convert.ToInt32(reader["Status"]),
                            });
                        }
                    }
                }
            }

            if (!records.Any())
            {
                return NotFound("No borrowing records found for this patron.");
            }

            return Ok(records);
        }

    }
}
