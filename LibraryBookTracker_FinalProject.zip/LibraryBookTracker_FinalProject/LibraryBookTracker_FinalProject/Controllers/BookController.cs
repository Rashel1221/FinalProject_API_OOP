﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using MySql.Data.MySqlClient;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using LibraryBookTracker_FinalProject.Model;
using System;

namespace LibraryBookTracker_FinalProject.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class BookController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        private string ConnectionString => _configuration.GetConnectionString("DefaultConnection");

        public BookController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        // GET /api/books - Accessible by both Librarians and Patrons
        [HttpGet]
        [Authorize(Roles = "librarian,patron")] // Both Librarians and Patrons can access
        public ActionResult<IEnumerable<Book>> GetAllBooks()
        {
            var books = new List<Book>();

            using (var connection = new MySqlConnection(ConnectionString))
            {
                connection.Open();
                string query = "SELECT * FROM Books";

                using (var command = new MySqlCommand(query, connection))
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        books.Add(new Book
                        {
                            BookId = Convert.ToInt32(reader["BookId"]),
                            Title = reader["Title"].ToString(),
                            Author = reader["Author"].ToString(),
                            ISBN = reader["ISBN"].ToString(),
                            PublishedDate = reader["PublishedDate"] as DateTime?,
                            Category = reader["Category"].ToString(),
                            TotalCopies = Convert.ToInt32(reader["TotalCopies"]),
                            AvailableCopies = Convert.ToInt32(reader["AvailableCopies"]),
                            CoverImageUrl = reader["CoverImageUrl"].ToString(),
                        });
                    }
                }
            }

            return Ok(books);
        }

        // GET /api/books/{book_id} - Accessible by both Librarians and Patrons
        [HttpGet("{book_id}")]
        [Authorize(Roles = "librarian,patron")] // Both Librarians and Patrons can access
        public ActionResult<Book> GetBook(int book_id)
        {
            using (var connection = new MySqlConnection(ConnectionString))
            {
                connection.Open();
                string query = "SELECT * FROM Books WHERE BookId = @BookId";

                using (var command = new MySqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@BookId", book_id);

                    using (var reader = command.ExecuteReader())
                    {
                        if (!reader.Read())
                        {
                            return NotFound("Book not found.");
                        }

                        var book = new Book
                        {
                            BookId = Convert.ToInt32(reader["BookId"]),
                            Title = reader["Title"].ToString(),
                            Author = reader["Author"].ToString(),
                            ISBN = reader["ISBN"].ToString(),
                            PublishedDate = reader["PublishedDate"] as DateTime?,
                            Category = reader["Category"].ToString(),
                            TotalCopies = Convert.ToInt32(reader["TotalCopies"]),
                            AvailableCopies = Convert.ToInt32(reader["AvailableCopies"]),
                            CoverImageUrl = reader["CoverImageUrl"].ToString(),
                        };

                        return Ok(book);
                    }
                }
            }
        }

        // POST /api/books - Accessible only by Librarians
        [HttpPost]
        [Authorize(Roles = "librarian")] // Only Librarians can add books
        public ActionResult AddBook([FromBody] Book book)
        {
            if (book == null || string.IsNullOrEmpty(book.Title) || string.IsNullOrEmpty(book.Author) || string.IsNullOrEmpty(book.ISBN) || book.TotalCopies <= 0 || book.AvailableCopies < 0)
            {
                return BadRequest("Invalid book data.");
            }

            book.CoverImageUrl ??= "https://example.com/default-cover.jpg";

            try
            {
                using (var connection = new MySqlConnection(ConnectionString))
                {
                    connection.Open();
                    string query = "INSERT INTO Books (Title, Author, ISBN, PublishedDate, Category, TotalCopies, AvailableCopies, CoverImageUrl) " +
                                   "VALUES (@Title, @Author, @ISBN, @PublishedDate, @Category, @TotalCopies, @AvailableCopies, @CoverImageUrl)";

                    using (var command = new MySqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@Title", book.Title);
                        command.Parameters.AddWithValue("@Author", book.Author);
                        command.Parameters.AddWithValue("@ISBN", book.ISBN);
                        command.Parameters.AddWithValue("@PublishedDate", book.PublishedDate ?? (object)DBNull.Value);
                        command.Parameters.AddWithValue("@Category", book.Category);
                        command.Parameters.AddWithValue("@TotalCopies", book.TotalCopies);
                        command.Parameters.AddWithValue("@AvailableCopies", book.AvailableCopies);
                        command.Parameters.AddWithValue("@CoverImageUrl", book.CoverImageUrl);

                        command.ExecuteNonQuery();
                    }
                }

                return Ok("Book added successfully.");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        // PUT /api/books/{book_id} - Accessible only by Librarians
        [HttpPut("{book_id}")]
        [Authorize(Roles = "librarian")] // Only Librarians can update books
        public ActionResult UpdateBook(int book_id, [FromBody] Book updatedBook)
        {
            using (var connection = new MySqlConnection(ConnectionString))
            {
                connection.Open();

                string query = "UPDATE Books SET Title = @Title, Author = @Author, ISBN = @ISBN, PublishedDate = @PublishedDate, " +
                               "Category = @Category, TotalCopies = @TotalCopies, AvailableCopies = @AvailableCopies , CoverImageUrl =@Image WHERE BookId = @BookId";

                using (var command = new MySqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@BookId", book_id);
                    command.Parameters.AddWithValue("@Title", updatedBook.Title);
                    command.Parameters.AddWithValue("@Author", updatedBook.Author);
                    command.Parameters.AddWithValue("@ISBN", updatedBook.ISBN);
                    command.Parameters.AddWithValue("@PublishedDate", updatedBook.PublishedDate);
                    command.Parameters.AddWithValue("@Category", updatedBook.Category);
                    command.Parameters.AddWithValue("@TotalCopies", updatedBook.TotalCopies);
                    command.Parameters.AddWithValue("@AvailableCopies", updatedBook.AvailableCopies);
                    command.Parameters.AddWithValue("@Image", updatedBook.CoverImageUrl);
                    int rowsAffected = command.ExecuteNonQuery();
                    if (rowsAffected == 0)
                    {
                        return NotFound("Book not found.");
                    }
                }
            }

            return Ok("Book updated successfully.");
        }

        // DELETE /api/books/{book_id} - Accessible only by Librarians
        [HttpDelete("{book_id}")]
        [Authorize(Roles = "librarian")] // Only Librarians can delete books
        public ActionResult DeleteBook(int book_id)
        {
            using (var connection = new MySqlConnection(ConnectionString))
            {
                connection.Open();
                string query = "DELETE FROM Books WHERE BookId = @BookId";

                using (var command = new MySqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@BookId", book_id);

                    int rowsAffected = command.ExecuteNonQuery();
                    if (rowsAffected == 0)
                    {
                        return NotFound("Book not found.");
                    }
                }
            }

            return Ok("Book deleted successfully.");
        }
    }
}
