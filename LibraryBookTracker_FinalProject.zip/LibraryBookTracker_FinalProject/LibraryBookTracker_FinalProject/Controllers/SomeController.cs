﻿using LibraryBookTracker_FinalProject.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;

namespace LibraryBookTracker_FinalProject.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class SomeController : ControllerBase
    {
        private readonly JwtServices _jwtServices;

        public SomeController(IOptions<JwtServices> jwtOptions)
        {
            _jwtServices = jwtOptions.Value;  // Access JwtServices configuration
        }

        [HttpGet("GetJwtSecret")]
        public ActionResult<string> GetJwtSecret()
        {
            return Ok(_jwtServices.Secret);  // Example of using the JwtServices
        }
    }
}
