﻿using LibraryBookTracker_FinalProject.Model;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;

namespace LibraryBookTracker_FinalProject.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize] // Require authentication for all endpoints
    public class BookSearchAndReportsController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        private string ConnectionString => _configuration.GetConnectionString("DefaultConnection");

        public BookSearchAndReportsController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        // GET /api/BookSearchAndReports/search
        [HttpGet("search")]
        public ActionResult<IEnumerable<Book>> SearchBooks([FromQuery] string title, [FromQuery] string author, [FromQuery] string category, [FromQuery] string isbn)
        {
            var books = new List<Book>();

            try
            {
                using (var connection = new MySqlConnection(ConnectionString))
                {
                    connection.Open();
                    string query = "SELECT * FROM Books WHERE 1=1";

                    if (!string.IsNullOrEmpty(title))
                        query += " AND Title LIKE @Title";
                    if (!string.IsNullOrEmpty(author))
                        query += " AND Author LIKE @Author";
                    if (!string.IsNullOrEmpty(category))
                        query += " AND Category LIKE @Category";
                    if (!string.IsNullOrEmpty(isbn))
                        query += " AND ISBN LIKE @ISBN";

                    using (var command = new MySqlCommand(query, connection))
                    {
                        if (!string.IsNullOrEmpty(title))
                            command.Parameters.AddWithValue("@Title", $"%{title}%");
                        if (!string.IsNullOrEmpty(author))
                            command.Parameters.AddWithValue("@Author", $"%{author}%");
                        if (!string.IsNullOrEmpty(category))
                            command.Parameters.AddWithValue("@Category", $"%{category}%");
                        if (!string.IsNullOrEmpty(isbn))
                            command.Parameters.AddWithValue("@ISBN", $"%{isbn}%");

                        using (var reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                books.Add(new Book
                                {
                                    BookId = Convert.ToInt32(reader["BookId"]),
                                    Title = reader["Title"].ToString(),
                                    Author = reader["Author"].ToString(),
                                    ISBN = reader["ISBN"].ToString(),
                                    Category = reader["Category"].ToString(),
                                    PublishedDate = reader["PublishedDate"] as DateTime?,
                                    TotalCopies = Convert.ToInt32(reader["TotalCopies"]),
                                    AvailableCopies = Convert.ToInt32(reader["AvailableCopies"]),
                                });
                            }
                        }
                    }
                }

                if (!books.Any())
                {
                    return NotFound("No books matched the search criteria.");
                }

                return Ok(books);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        // GET /api/BookSearchAndReports/reports/overdue
        [HttpGet("reports/overdue")]
        public ActionResult<IEnumerable<BorrowingRecord>> GetOverdueRecords()
        {
            var overdueRecords = new List<BorrowingRecord>();

            try
            {
                using (var connection = new MySqlConnection(ConnectionString))
                {
                    connection.Open();
                    string query = "SELECT * FROM BorrowingRecords WHERE Status = @Status AND DueDate < @CurrentDate";

                    using (var command = new MySqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@Status", (int)BorrowingStatus.Borrowed);
                        command.Parameters.AddWithValue("@CurrentDate", DateTime.Now);

                        using (var reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                overdueRecords.Add(new BorrowingRecord
                                {
                                    BorrowId = Convert.ToInt32(reader["BorrowId"]),
                                    BookId = Convert.ToInt32(reader["BookId"]),
                                    PatronId = Convert.ToInt32(reader["PatronId"]),
                                    BorrowDate = Convert.ToDateTime(reader["BorrowDate"]),
                                    DueDate = Convert.ToDateTime(reader["DueDate"]),
                                    ReturnDate = reader["ReturnDate"] as DateTime?,
                                    Status = (BorrowingStatus)Convert.ToInt32(reader["Status"]),
                                });
                            }
                        }
                    }
                }

                if (!overdueRecords.Any())
                {
                    return NotFound("No overdue borrowing records found.");
                }

                return Ok(overdueRecords);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        // GET /api/BookSearchAndReports/reports/popular-books
        [HttpGet("reports/popular-books")]
        public ActionResult<IEnumerable<Book>> GetPopularBooks()
        {
            var popularBooks = new List<Book>();

            try
            {
                using (var connection = new MySqlConnection(ConnectionString))
                {
                    connection.Open();
                    string query = @"
                        SELECT b.*, COUNT(br.BorrowId) AS BorrowCount
                        FROM Books b
                        JOIN BorrowingRecords br ON b.BookId = br.BookId
                        GROUP BY b.BookId
                        ORDER BY BorrowCount DESC
                        LIMIT 10";

                    using (var command = new MySqlCommand(query, connection))
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            popularBooks.Add(new Book
                            {
                                BookId = Convert.ToInt32(reader["BookId"]),
                                Title = reader["Title"].ToString(),
                                Author = reader["Author"].ToString(),
                                ISBN = reader["ISBN"].ToString(),
                                Category = reader["Category"].ToString(),
                                PublishedDate = reader["PublishedDate"] as DateTime?,
                                TotalCopies = Convert.ToInt32(reader["TotalCopies"]),
                                AvailableCopies = Convert.ToInt32(reader["AvailableCopies"]),
                            });
                        }
                    }
                }

                if (!popularBooks.Any())
                {
                    return NotFound("No popular books found.");
                }

                return Ok(popularBooks);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }
    }
}
