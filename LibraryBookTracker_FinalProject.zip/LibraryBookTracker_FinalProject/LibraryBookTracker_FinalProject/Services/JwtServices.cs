﻿using Org.BouncyCastle.Bcpg.OpenPgp;

namespace LibraryBookTracker_FinalProject.Services
{
    public class JwtServices
    {
        public string Secret { get; set; }
        public string Issuer { get; set; }
        public string Audience { get; set; }
        public double ExpirationInminutes {  get; set; }
    }
}
