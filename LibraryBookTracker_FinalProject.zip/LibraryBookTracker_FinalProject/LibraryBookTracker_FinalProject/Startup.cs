﻿using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using System.Text;
using System.Threading.Tasks;
using LibraryBookTracker_FinalProject.Services;

public class Startup
{
    private readonly IConfiguration _configuration;

    public Startup(IConfiguration configuration)
    {
        _configuration = configuration;
    }

    // This method is used to add services to the container.
    public void ConfigureServices(IServiceCollection services)
    {
        // Register JwtServices for DI
        services.Configure<JwtServices>(_configuration.GetSection("JwtServices"));

        // JWT Authentication setup
        services.AddAuthentication(options =>
        {
            options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
            options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
        })
        .AddJwtBearer(options =>
        {
            options.TokenValidationParameters = new TokenValidationParameters
            {
                ValidateIssuer = true,
                ValidateAudience = true,
                ValidateLifetime = true,
                ValidateIssuerSigningKey = true,
                ValidIssuer = _configuration["JwtSettings:Issuer"],
                ValidAudience = _configuration["JwtSettings:Audience"],
                IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["JwtSettings:Key"]))
            };

            // Optional: Handle token validation failure responses
            options.Events = new JwtBearerEvents
            {
                OnAuthenticationFailed = context =>
                {
                    // Log the error or perform any actions needed
                    return Task.CompletedTask;
                },
                OnChallenge = context =>
                {
                    // Customize the challenge response for missing or invalid JWT
                    return Task.CompletedTask;
                }
            };
        });

        // Add other services like controllers, Swagger, etc.
        services.AddControllers();
        services.AddEndpointsApiExplorer();

        // Add Swagger configuration
        services.AddSwaggerGen(options =>
        {
            // Add Bearer token authorization for Swagger UI
            options.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
            {
                Name = "Authorization",
                Type = SecuritySchemeType.ApiKey,
                Scheme = "bearer",
                BearerFormat = "JWT",
                In = ParameterLocation.Header,
                Description = "Enter 'Bearer' followed by your JWT token"
            });

            options.AddSecurityRequirement(new OpenApiSecurityRequirement
            {
                {
                    new OpenApiSecurityScheme
                    {
                        Reference = new OpenApiReference
                        {
                            Type = ReferenceType.SecurityScheme,
                            Id = "Bearer"
                        }
                    },
                    new string[] { }
                }
            });
        });
    }

    // This method is used to configure the HTTP request pipeline.
    public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
    {
        if (env.IsDevelopment())
        {
            app.UseSwagger();
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "Inventory Management API V1");
                // Optional: You can set a custom Swagger UI route if needed
                // c.RoutePrefix = string.Empty; // Uncomment if you want Swagger UI at the root of the app
            });
        }

        // Enable HTTPS redirection
        app.UseHttpsRedirection();

        // Enable Authentication and Authorization Middleware
        app.UseAuthentication(); // This ensures that JWT tokens are validated
        app.UseAuthorization(); // This will check if the user has the right permissions

        // Configure routing and endpoints
        app.UseRouting();
        app.UseEndpoints(endpoints =>
        {
            endpoints.MapControllers();
        });
    }
}
