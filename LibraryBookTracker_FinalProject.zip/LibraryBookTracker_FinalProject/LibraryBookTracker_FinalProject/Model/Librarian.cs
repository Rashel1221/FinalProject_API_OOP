﻿namespace LibraryBookTracker_FinalProject.Model
{
    public class Librarian
    {
        public int LibrarianId { get; set; } // Primary Key
        public string FirstName { get; set; } // NOT NULL
        public string LastName { get; set; } // NOT NULL
        public string Email { get; set; } // UNIQUE, NOT NULl

        public string Username { get; set; }
        public string Password { get; set; }
        public string Role { get; set; }
    }
}
