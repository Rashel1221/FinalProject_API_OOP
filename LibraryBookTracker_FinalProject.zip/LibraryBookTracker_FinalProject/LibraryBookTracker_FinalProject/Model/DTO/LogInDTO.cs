﻿namespace LibraryBookTracker_FinalProject.Model.DTO
{
   
        public class LogInDTO
        {
            public string Username { get; set; }
            public string Password { get; set; }
            public string Platform { get; set; }

        }
    
}
