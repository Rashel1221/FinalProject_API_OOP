﻿namespace LibraryBookTracker_FinalProject.Model
{
    public enum BorrowingStatus
    {
        PendingApproval = 0,
        Borrowed = 1,
        Returned = 2,
        Rejected = 3,
        Overdue =4,
    }

    public class BorrowingRecord
    {
        public int BorrowId { get; set; }
        public int BookId { get; set; }
        public int PatronId { get; set; }
        //public string Fullname { get; set; }
        public DateTime BorrowDate { get; set; }
        public DateTime DueDate { get; set; }
        public DateTime? ReturnDate { get; set; }
        public BorrowingStatus Status { get; set; } // Use the enum here
    }
}
