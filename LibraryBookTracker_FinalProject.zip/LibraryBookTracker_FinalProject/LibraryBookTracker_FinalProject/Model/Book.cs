﻿namespace LibraryBookTracker_FinalProject.Model
{
    public class Book
    {
        public int BookId { get; set; } // Primary Key
        public string Title { get; set; } // NOT NULL
        public string Author { get; set; } // NOT NULL
        public string ISBN { get; set; } // UNIQUE, NOT NULL
        public DateTime? PublishedDate { get; set; } // NULL
        public string Category { get; set; } // NULL
        public int TotalCopies { get; set; } // NOT NULL
        public int AvailableCopies { get; set; } // NOT NULL
        public string CoverImageUrl { get; set; }
    }
}
