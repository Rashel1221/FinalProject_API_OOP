﻿namespace LibraryBookTracker_FinalProject.Model
{
    public class Patron
    {
            public int PatronsId { get; set; } // Primary Key
            public string ProfilePic { get; set; }
            public string FirstName { get; set; } // NOT NULL
            public string LastName { get; set; } // NOT NULL
            public string Email { get; set; } // UNIQUE, NOT NULL
            public string PhoneNumber { get; set; } // UNIQUE, NULL
            public DateTime JoinDate { get; set; } // NOT NULL
            public string Role { get; set; }

        public string Username { get; set; }
        public string Password { get; set; }

    }
}
